    # ANCHA ARUMI - Android Studio Project (v1.2)

    Ini adalah project scaffold untuk **ANCHA ARUMI Mp3 PLAYER** (Kotlin) versi 1.2.

    Perubahan utama:

    - Integrasi **mobile-ffmpeg** (com.arthenica:mobile-ffmpeg-full:4.4.LTS) untuk trimming dan pemrosesan audio yang lebih andal.
"
    - GitHub Actions workflow yang membangun APK dan mengunggah APK sebagai artifact.


    ## Cara pakai workflow (Repo PRIVATE)

    1. Buat repository baru di GitHub (pilih Private).
    2. Push semua file dari folder `ANCHA_ARUMI_project_v3` ke repo tersebut (branch `main` atau `master`).
    3. Buka tab **Actions** di GitHub repo — workflow `Android CI - Build APK` akan berjalan otomatis pada push.
    4. Setelah workflow selesai, buka job `build` → Artifacts → unduh `ancha_arumi_apk` (hanya pengguna yang punya akses repo/private actions dapat melihatnya).

    ## Catatan penting

    - Karena repo private, hanya akun GitHub dengan akses repo yang bisa menjalankan workflow dan mengunduh APK.
    - Pastikan branch default adalah `main` atau `master` sesuai trigger di workflow, atau ubah `on.push.branches` di workflow.
    - Jika build gagal karena Android SDK/tools, kamu bisa menginstal toolchain yang diperlukan di workflow atau gunakan image runner yang sudah tersedia via actions/setup-android (butuh konfigurasi tambahan).

    ## FFmpeg trimming

    - RingtoneCutterActivity sekarang menggunakan Mobile-FFmpeg untuk perintah trimming: `-ss START -to END -c copy`.
    - Jika trimming gagal untuk beberapa file, coba gunakan opsi re-encode (`-c:a libmp3lame`) tetapi akan memperlambat proses.

    ## Lanjutkan

    Jika mau, saya bisa:
    - Menulis file `README_PUSH.md` berisi perintah git push satu baris untuk pemula.
    - Tambahkan signature release atau set up Fastlane di workflow untuk membuat release otomatis.

    Sampaikan apa lagi yang mau saya tambahkan.
