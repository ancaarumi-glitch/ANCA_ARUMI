package com.anca.arumi

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PlaylistAdapter(private val data: List<AudioFile>, private val onClick: (AudioFile) -> Unit)
    : RecyclerView.Adapter<PlaylistAdapter.VH>() {

    class VH(view: View): RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(android.R.id.text1)
        val subtitle: TextView = view.findViewById(android.R.id.text2)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_2, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = data[position]
        holder.title.text = item.title
        holder.subtitle.text = (item.duration/1000).toString() + " s — " + item.path
        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = data.size
}
