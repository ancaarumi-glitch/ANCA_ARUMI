package com.anca.arumi

import android.content.Context
import android.database.Cursor
import android.provider.MediaStore
import java.io.File

data class AudioFile(val id: Long, val title: String, val path: String, val duration: Long)

object FileScanner {
    fun scanAudioFiles(context: Context): List<AudioFile> {
        val result = mutableListOf<AudioFile>()
        val projection = arrayOf(MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DURATION)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC}=1 OR ${MediaStore.Audio.Media.IS_PODCAST}=1"
        val cursor: Cursor? = context.contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")
        cursor?.use {
            val idIdx = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleIdx = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val dataIdx = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val durIdx = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (it.moveToNext()) {
                val id = it.getLong(idIdx)
                val title = it.getString(titleIdx) ?: File(it.getString(dataIdx)).name
                val path = it.getString(dataIdx)
                val dur = it.getLong(durIdx)
                result.add(AudioFile(id, title, path, dur))
            }
        }
        return result
    }
}
