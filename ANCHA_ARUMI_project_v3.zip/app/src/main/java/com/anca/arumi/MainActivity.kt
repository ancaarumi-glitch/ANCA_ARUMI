package com.anca.arumi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    private lateinit var rv: RecyclerView
    private var list = listOf<AudioFile>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Request runtime permissions (simple)
        requestPermissionsIfNeeded()

        val btnPlay = findViewById<MaterialButton>(R.id.btnPlay)
        val btnRecord = findViewById<MaterialButton>(R.id.btnRecord)
        val btnEqual = findViewById<MaterialButton>(R.id.btnEqual)
        val btnCutter = findViewById<MaterialButton>(R.id.btnCutter)
        rv = findViewById(R.id.rvPlaylist)
        rv.layoutManager = LinearLayoutManager(this)

        btnPlay.setOnClickListener {
            val intent = Intent(this, PlaybackService::class.java)
            intent.action = PlaybackService.ACTION_TOGGLE_PLAY
            ContextCompat.startForegroundService(this, intent)
        }

        btnRecord.setOnClickListener {
            val i = Intent(this, RecorderActivity::class.java)
            startActivity(i)
        }

        btnEqual.setOnClickListener {
            startActivity(Intent(this, EqualizerActivity::class.java))
        }

        btnCutter.setOnClickListener {
            startActivity(Intent(this, RingtoneCutterActivity::class.java))
        }

        refreshPlaylist()
    }

    private fun refreshPlaylist() {
        list = FileScanner.scanAudioFiles(this)
        val adapter = PlaylistAdapter(list) { item ->
            val i = Intent(this, RingtoneCutterActivity::class.java)
            i.putExtra("path", item.path)
            i.putExtra("duration", (item.duration/1000).toInt())
            startActivity(i)
        }
        rv.adapter = adapter
    }

    private fun requestPermissionsIfNeeded() {
        val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val needed = perms.filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            if (needed.isNotEmpty()) {
                requestPermissions(needed.toTypedArray(), 1001)
            }
        }
    }
}
