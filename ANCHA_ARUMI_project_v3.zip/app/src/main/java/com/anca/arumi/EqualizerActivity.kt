package com.anca.arumi

import android.media.audiofx.Equalizer
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class EqualizerActivity : AppCompatActivity() {

    private var equalizer: Equalizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,16,16,16) }
        setContentView(layout)

        equalizer = Equalizer(0, 0)
        equalizer?.setEnabled(true)

        val nbands = equalizer?.numberOfBands ?: 0
        val lower = equalizer?.bandLevelRange?.get(0) ?: 0.toShort()
        val upper = equalizer?.bandLevelRange?.get(1) ?: 0.toShort()

        for (i in 0 until nbands) {
            val tv = TextView(this)
            val freq = equalizer?.getCenterFreq(i.toShort())?.div(1000) ?: 0
            tv.text = "Band ${i+1} — ${freq} Hz"
            val sb = SeekBar(this)
            sb.max = (upper - lower).toInt()
            sb.progress = (equalizer?.getBandLevel(i.toShort())?.minus(lower))?.toInt() ?: 0
            sb.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val level = (progress + lower).toShort()
                    equalizer?.setBandLevel(i.toShort(), level)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            layout.addView(tv)
            layout.addView(sb)
        }
    }

    override fun onDestroy() {
        equalizer?.release()
        equalizer = null
        super.onDestroy()
    }
}
