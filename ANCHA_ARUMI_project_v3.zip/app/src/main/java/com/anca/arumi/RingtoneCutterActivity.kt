package com.anca.arumi

import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.arthenica.mobileffmpeg.FFmpeg
import java.io.File

class RingtoneCutterActivity : AppCompatActivity() {

    private lateinit var tvPath: TextView
    private lateinit var sbStart: SeekBar
    private lateinit var sbEnd: SeekBar
    private lateinit var btnSave: Button
    private var selectedPath: String? = null
    private var durationSec: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ringtone_cutter)
        tvPath = findViewById(R.id.tvPath)
        sbStart = findViewById(R.id.sbStart)
        sbEnd = findViewById(R.id.sbEnd)
        btnSave = findViewById(R.id.btnSaveCut)
        selectedPath = intent.getStringExtra("path")
        tvPath.text = selectedPath ?: "Pilih lagu dari playlist"

        durationSec = intent.getIntExtra("duration", 30)
        if (durationSec <= 0) durationSec = 30

        sbStart.max = durationSec
        sbEnd.max = durationSec
        sbEnd.progress = durationSec

        btnSave.setOnClickListener {
            val s = sbStart.progress
            val e = sbEnd.progress
            if (selectedPath != null && e > s) {
                val out = File(externalCacheDir, "cut_${System.currentTimeMillis()}.mp3")
                Thread {
                    val cmd = arrayOf("-y", "-i", selectedPath, "-ss", s.toString(), "-to", e.toString(), "-c", "copy", out.absolutePath)
                    val rc = FFmpeg.execute(cmd)
                    runOnUiThread {
                        if (rc == 0) tvPath.text = "Tersimpan: ${out.absolutePath}" else tvPath.text = "Gagal memotong file (code $rc)"
                    }
                }.start()
            }
        }
    }
}
