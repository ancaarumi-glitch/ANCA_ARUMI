package com.anca.arumi

import android.media.MediaRecorder
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class RecorderActivity : AppCompatActivity() {
    private var recorder: MediaRecorder? = null
    private lateinit var outFile: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recorder)
        outFile = externalCacheDir?.absolutePath + File.separator + "rec_anca.wav"
        val btnRec = findViewById<Button>(R.id.btnRec)
        btnRec.setOnClickListener {
            if (recorder == null) startRecording() else stopRecording()
        }
    }

    private fun startRecording() {
        recorder = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
            setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
            setOutputFile(outFile)
            prepare()
            start()
        }
    }

    private fun stopRecording() {
        recorder?.apply {
            stop()
            release()
        }
        recorder = null
    }
}
